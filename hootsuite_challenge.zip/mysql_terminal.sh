#!/bin/bash
sudo docker run -it --network challenge_default --rm mysql mysql -ham-db -uroot -p
